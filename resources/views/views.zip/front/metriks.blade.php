@section('metriks')
    {!! $static->metrik_field !!}
@endsection
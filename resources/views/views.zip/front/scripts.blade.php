@section('scripts')
    <script src="/js/jquery.min.js"></script>
    <script src="/js/jquery.magnific-popup.js"></script>
    <script src="/js/jquery.mask.js"></script>
    <script src="/js/popupForm.js"></script>
    <script src="/js/jquery.bxslider.js"></script>
    <script src="/js/jquery.elevatezoom.js"></script>
    <script src="/js/raiting.js"></script>
    <script src="/js/animate.js"></script>
    <script src="/js/main.js"></script>
    {{--<script crossorigin="anonymous" async type="text/javascript" src="//api.pozvonim.com/widget/callback/v3/3353ad4817b50083cfd0c2ffba2b72b9/connect" id="check-code-pozvonim" charset="UTF-8"></script>
    <script type="text/javascript" src="//cdn.callbackhunter.com/cbh.js?hunter_code=21a39ec775982af5b06964d7f7996de3"
            charset="UTF-8"></script>
    <!-- Chatra {literal} -->
    <script>
        (function(d, w, c) {
            w.ChatraID = 'PEo8Wqk4rkzYKvayF';
            var s = d.createElement('script');
            w[c] = w[c] || function() {
                        (w[c].q = w[c].q || []).push(arguments);
                    };
            s.async = true;
            s.src = (d.location.protocol === 'https:' ? 'https:': 'http:')
                    + '//call.chatra.io/chatra.js';
            if (d.head) d.head.appendChild(s);
        })(document, window, 'Chatra');
    </script>
    <!-- /Chatra {/literal} -->--}}
@endsection
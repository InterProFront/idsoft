@section('meta')
    <title>{{$wipon->page_title_field}}</title>
    <meta name="description" content="{{$wipon->seo_description_field}}">
    <meta name="keywords" content="{{$wipon->seo_keywords_field}}">
    @include('front.seotext',['seo_text' => $wipon->seo_text_field])
@endsection
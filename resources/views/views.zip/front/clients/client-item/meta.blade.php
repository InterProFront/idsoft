@section('meta')
    <title>{{$client->page_title_field}}</title>
    <meta name="description" content="{{$client->seo_description_field}}">
    <meta name="keywords" content="{{$client->seo_keywords_field}}">
@endsection
@section('meta')
    <title>{{$inf->page_title_field}}</title>
    <meta name="description" content="{{$inf->seo_description_field}}">
    <meta name="keywords" content="{{$inf->seo_keywords_field}}">
@endsection
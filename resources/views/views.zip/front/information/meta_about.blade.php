@section('meta')
    <title>{{$about->page_title_field}}</title>
    <meta name="description" content="{{$about->seo_description_field}}">
    <meta name="keywords" content="{{$about->seo_keywords_field}}">
@endsection
<div class="hide">
    <div class="white-popup mfp-with-anim mfp-hide" id="thanks">
        <h4 class="popup-title">Сообщение отправлено!</h4>
        <p class="sub-title-text">Спасибо, мы свяжемся с вами в ближайшее время.</p>
    </div>
</div>
@section('seotext')
    <div class="seo-text">{!! $seo_text  !!}</div>
@endsection
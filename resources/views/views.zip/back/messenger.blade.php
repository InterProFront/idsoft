@section('messenger')
    <div class="block fixed">
        <div class="message-container">
            <p></p>
        </div>
    </div>
@endsection
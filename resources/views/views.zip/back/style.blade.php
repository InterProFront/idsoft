@section('styles')
    <link rel="stylesheet" href="/Admin/css/trumbowyg.min.css">
    <link rel="stylesheet" href="/Admin/css/style.css">
@endsection

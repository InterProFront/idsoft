<h1>Заказ продукта</h1>
<p>Имя: {{$item->name_field}}</p>
<p>Почта: {{$item->mail_field}}</p>
<p>Телефон: {{$item->phone_field}}</p>
<p>Комментарий: {{$item->question_field}}</p>
<p>Товар: {{$item->product_field}}</p>

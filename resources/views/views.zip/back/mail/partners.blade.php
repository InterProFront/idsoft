<h1>Заявка «Стать партнером»</h1>
<p>Название компании: {{$item->company_name_field}}</p>
<p>Адрес сайта: {{$item->site_name_field}}</p>
<p>Контактный телефон: {{$item->contact_phone_field}}</p>
<p>Эл. Почта: {{$item->mail_field}}</p>
<p>Город: {{$item->city_field}}</p>
<p>Комментарий: {{$item->question_field}}</p>

<h1>Вопрос от пользователя</h1>
<p>Имя: {{$item->name_field}}</p>
<p>Почта: {{$item->mail_field}}</p>
<p>Вопрос: {{$item->question_field}}</p>
